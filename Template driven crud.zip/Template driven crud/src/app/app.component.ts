import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'project1';
  userform!: NgForm
  studentarr: any[] = [];
  student: any = {

    studentid: 0,
    fullname: '',
    mobile: '',
    email: '',
    address: ''
  };
  constructor() { }

  ngOnInit(): void {
    // exexute before component , cuz hen tab refresh so data go in table ,but ls me rehta hai to retive it .getitem
    const localdata = localStorage.getItem('studentlist');
    if (localdata != null) {
      this.studentarr = JSON.parse(localdata)
    }

  }


  addstudent() {
    debugger
    let notnull = document.getElementById('addstudent');
    if (notnull != null) {
      notnull.style.display = 'block';
    }
  }
  closethepopup() {
    let notnull = document.getElementById('addstudent');
    if (notnull != null) {
      notnull.style.display = 'none';
    }
    this.student = {
      studentid: 0,
      fullname: '',
      mobile: '',
      email: '',
      address: ''
    }
  }
  Onsave(data: any) {
    this.student.studentid = this.studentarr.length + 1;
    this.studentarr.push(this.student)
    this.closethepopup()
    window.localStorage.setItem('studentlist', JSON.stringify(this.studentarr))
    this.student = {
      studentid: 0,
      fullname: '',
      mobile: '',
      email: '',
      address: ''
    }
  }
  onEdit(stud: any) {

    // open the pop form
    this.addstudent()
    // full the form width the currnetdata
    this.student = stud;
  }

  onupdate(data: any) {

    let record = this.studentarr.find(m => m.studentid == this.student.studentid);
    record.fullname = this.student.fullname;
    record.mobile = this.student.mobile;
    record.email = this.student.email;
    record.address = this.student.address;
    window.localStorage.setItem('studentlist', JSON.stringify(this.studentarr))
    this.student = {
      studentid: 0,
      fullname: '',
      mobile: '',
      email: '',
      address: ''
    }
    this.closethepopup()


  }
  ondelete(id: number) {

    for (let i = 0; i < this.studentarr.length; i++) {

      if (this.studentarr[i].studentid == id) {
        this.studentarr.splice(i, 1)
      }
    }
    window.localStorage.setItem('studentlist', JSON.stringify(this.studentarr))
  }


}
