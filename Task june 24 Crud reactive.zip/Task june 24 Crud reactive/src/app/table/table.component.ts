import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
  newpopup!: FormGroup
  headings = [
    "S.no",
    "First name",
    "Last name",
    "Department",
    "Username",
    "Password",
    "Cnf password",
    "Email",
    "Contact",
    "Actions"
  ]
  obj: any[] = []
  ngOnInit(): void {
    let localdata = localStorage.getItem('signup');
    if (localdata != null) {
      this.obj = JSON.parse(localdata)
    }


    this.newpopup = new FormGroup({
      'Firstname': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Lastname': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Email': new FormControl(null, [Validators.required, Validators.email]),
      'Contact': new FormControl(null, [Validators.required, Validators.pattern('[0-9]{10}')]),
      'Dept': new FormControl(null, [Validators.required]),
      'Username': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Password': new FormControl(null, [Validators.required]),
      'Confirmpassword': new FormControl(null, [Validators.required]),
    })
  }



  ondelete(id: number) {
    this.obj.splice(id, 1);
    localStorage.setItem('signup', JSON.stringify(this.obj));
  }


  onedit(data: any, id: number) {
    let a = document.getElementById('popup');
    if (a != null) {
      a.style.display = 'block';
    }
    
    this.newpopup = new FormGroup({
      'Firstname': new FormControl(data.Firstname, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Lastname': new FormControl(data.Lastname, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Email': new FormControl(data.Email, [Validators.required, Validators.email]),
      'Contact': new FormControl(data.Contact, [Validators.required, Validators.pattern('[0-9]{10}')]),
      'Dept': new FormControl(data.Dept, [Validators.required]),
      'Username': new FormControl(data.Username, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Password': new FormControl(data.Password, [Validators.required]),
      'Confirmpassword': new FormControl(data.Confirmpassword, [Validators.required]),
    })

    this.ondelete(id);
  

  }

  oncross() {
    let a = document.getElementById('popup');
    if (a != null) {
      a.style.display = 'none';
    }
  }
  onupdate(){


    if(this.newpopup.value.Password == this.newpopup.value.Confirmpassword ){
      this.obj.push(this.newpopup.value);
      localStorage.setItem('signup', JSON.stringify(this.obj));
      this.oncross();
    }
    else{
      console.error(' Cannot update , Password and Confirmpassword  does not match!!!!!');
    }


  }

 
}




