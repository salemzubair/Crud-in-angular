import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  myform!: FormGroup;

  ngOnInit(): void {

    this.myform = new FormGroup({
      'Firstname': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Lastname': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Email': new FormControl(null, [Validators.required, Validators.email]),
      'Contact': new FormControl(null, [Validators.required ,Validators.pattern('[0-9]{10}')]),
      'Dept': new FormControl(null, [Validators.required]),
      'Username': new FormControl(null, [Validators.required, Validators.pattern('[A-Za-z]{3,30}')]),
      'Password': new FormControl(null, [Validators.required , ]),
      'Confirmpassword': new FormControl(null, [Validators.required ]),
    })

    let localdata = localStorage.getItem('signup');
    if (localdata != null) {
      this.obj = JSON.parse(localdata)
    }
  }
  obj: any[] = []
  onsubmit() {

    // this.obj.push(this.myform.value);
    // localStorage.setItem('signup', JSON.stringify(this.obj));
    // this.myform.reset();
    if(this.myform.value.Password == this.myform.value.Confirmpassword )
    {
      this.obj.push(this.myform.value);
    localStorage.setItem('signup', JSON.stringify(this.obj));
    this.myform.reset();
    }
    else{
      console.error('Password and Confirmpassword  does not match!!!!!');
      
    }

  }

}
