import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'project2';
  myreactiveform!: FormGroup


  ngOnInit(): void {
    // Reading  data fiorm localstorage
    const localdata = localStorage.getItem('mystudents');
    if (localdata != null) {
      this.obj = (JSON.parse(localdata))
    }
    // [a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"

    // Defining  the  form
    this.myreactiveform = new FormGroup({

      'fullname': new FormControl(null, [Validators.required, Validators.pattern('A-Za-z')]),
      'email': new FormControl(null, [Validators.required, Validators.email, Validators.pattern('a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]),
      'mobile': new FormControl(null, [Validators.required, Validators.pattern("[0-9]{10}")]),

      'address': new FormControl(null, Validators.required),

    })
  }


  obj: any[] = []

  // headings of table
  tableheadings = ['Sno', 'Fullname', 'Email', 'Address', 'Mobile', 'Actions']



  //  On submitting form and click onnsave
  onsave() {
    console.log(this.myreactiveform);
    this.obj.push(this.myreactiveform.value)
    localStorage.setItem('mystudents', JSON.stringify(this.obj))
    this.oncross();
    console.log(this.obj);
    this.oncross();


  }


  // On click on this X
  oncross() {
    let target1 = document.getElementById('addstudent')
    if (target1 != null) {
      target1.style.display = 'none'
    }
  }

  // on clicking on add student button on the header part
  onaddstudent() {
    let target1 = document.getElementById('addstudent')
    if (target1 != null) {
      target1.style.display = 'block'
    }
    this.myreactiveform.reset();
  }

  // On edit button add student popup and then  save button to save
  onedit(data: any, id: number) {
    this.onaddstudent();

    this.myreactiveform = new FormGroup({

      'fullname': new FormControl(data.fullname),
      'email': new FormControl(data.email),
      'mobile': new FormControl(data.mobile),
      'address': new FormControl(data.address),

    })
    localStorage.setItem('mystudents', JSON.stringify(this.obj))
    this.ondelete(id)

  }


  // On clicking the remove button 
  ondelete(id: number) {
    this.obj.splice(id, 1)
    localStorage.setItem('mystudents', JSON.stringify(this.obj))
  }



}
