import { Component } from '@angular/core';

@Component({
  selector: 'app-companyheading',
  templateUrl: './companyheading.component.html',
  styleUrls: ['./companyheading.component.scss']
})
export class CompanyheadingComponent {

}
