import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyheadingComponent } from './companyheading.component';

describe('CompanyheadingComponent', () => {
  let component: CompanyheadingComponent;
  let fixture: ComponentFixture<CompanyheadingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanyheadingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompanyheadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
