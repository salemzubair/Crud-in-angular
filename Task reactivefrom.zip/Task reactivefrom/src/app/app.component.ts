import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'project2';

  isform: boolean = true;
  mytable: boolean = true;
  both:boolean=false;
  [x: string]: any;

  myform!: FormGroup;
  ngOnInit() {
    this.myform = new FormGroup({
      'Firstname': new FormControl('', Validators.required),
      'Lastname': new FormControl('', Validators.required),
      'dob': new FormControl('', Validators.required),
      'Email': new FormControl('', [Validators.required, Validators.email]),
      'Mobile': new FormControl('', Validators.required),
      'Gender': new FormControl('', Validators.required),
      'Address': new FormControl('', Validators.required),
      'City': new FormControl('', Validators.required),
      'Pincode': new FormControl('', Validators.required),
      'State': new FormControl('', Validators.required),
      'Country': new FormControl('INDIA'),
      'Hobbies': new FormControl('', Validators.required),
      'Courses': new FormControl('', Validators.required),

      'ten_board': new FormControl('', Validators.required),
      'ten_percentage': new FormControl('', Validators.required),
      'ten_year': new FormControl('', Validators.required),

      'twelwe_board': new FormControl('', Validators.required),
      'twelwe_percentage': new FormControl('', Validators.required),
      'twelwe_year': new FormControl('', Validators.required),

      'grad_board': new FormControl('', Validators.required),
      'grad_percentage': new FormControl('', Validators.required),
      'grad_year': new FormControl('', Validators.required),

      'masters_board': new FormControl('', Validators.required),
      'masters_percentage': new FormControl('', Validators.required),
      'masters_year': new FormControl('', Validators.required),


    })
  }
  obj: any[] = []
  hobbies: string[] = []
  onsubmit() {
    console.log(this.myform);

    this.obj.push(this.myform.value);
    this.myform.value.Hobbies = this.hobbies;
    this.hobbies = []
    this.myform.reset();


  }

  checkhobbies(e: any, type: string) {
    if (e.target.checked) {
      this.hobbies.push(type);
    }
    else {
      if (this.hobbies.includes(type)) {
        this.hobbies.splice(this.hobbies.indexOf(type), 1)
      }
    }

  }
}
